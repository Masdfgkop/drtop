<img src="https://telegra.ph/file/1515d357035a1ca8b72d6.jpg" align="right" width="200" height="200"/>

# Gohara Music Bot

[سورس جوهره ميوزك](https://github.com/mohamedhelal12/gohara) هوه السورس المعرب الوحيد 

## 🖇 تنصيب هيروكو

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/goharaM/gohara"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-red?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
## 🖇 بوت الجلسات

<p>
<a href="https://t.me/helal_trmix_BOT"><img src="https://img.shields.io/badge/Generate%20On%20Repl-blueviolet?style=for-the-badge&logo=appveyor" width="200""/></a>
</p>

## 🖇 موقع التواصل تلجرام
- modY Channel :- [Channel](https://t.me/M_O_D_Y_CH)
- DEV :- [Source](https://t.me/MohamedHelal_l)
- Support Group :- [Support](https://t.me/BarGohara)




